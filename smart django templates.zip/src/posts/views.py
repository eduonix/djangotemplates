from django.shortcuts import render

from .models import Post

def post_list_view(request):
    our_post_models = Post.objects.all()
    context = {
        'our_posts': our_post_models
    }
    return render(request, "templates/post_list.html", context)

def post_detail_view(request, id):
    post = Post.objects.filter(id=id).first()
    context = {
        'post': post
    }
    return render(request, "templates/post_detail.html", context)